# BD: Guião 6

## Problema 6.1

### *a)* Todos os tuplos da tabela autores (authors);

```
select * from authors;
```

### *b)* O primeiro nome, o último nome e o telefone dos autores;

```
select au_fname, au_lname, phone from authors
```

### *c)* Consulta definida em b) mas ordenada pelo primeiro nome (ascendente) e depois o último nome (ascendente); 

```
select au_fname, au_lname, phone from authors order by au_fname, au_lname;
```

### *d)* Consulta definida em c) mas renomeando os atributos para (first_name, last_name, telephone); 

```
select au_fname as firstname, au_lname as lastname, phone as telephone from authors 
order by au_fname asc, au_lname;
```

### *e)* Consulta definida em d) mas só os autores da Califórnia (CA) cujo último nome é diferente de ‘Ringer’; 

```
select au_fname as firstname, au_lname as lastname, phone as telephone 
from authors 
where au_lname  != 'Ringer' and state = 'CA'
order by au_fname, au_lname;
```

### *f)* Todas as editoras (publishers) que tenham ‘Bo’ em qualquer parte do nome; 

```
select * from publishers 
where pub_name like '%Bo%'
```

### *g)* Nome das editoras que têm pelo menos uma publicação do tipo ‘Business’; 

```
select pub_name from publishers as p inner join titles as t on p.pub_id = t.pub_id
where type= 'business'
group by pub_name
```

### *h)* Número total de vendas de cada editora; 

```
select pub_id, NTotalVendas=sum(s.qty)  from sales as s inner join titles as t on s.title_id = t.title_id
group by pub_id;
```

### *i)* Número total de vendas de cada editora agrupado por título; 

```
select pub_id ,title , NTotalVendas=sum(s.qty)  from sales as s inner join titles as t on s.title_id = t.title_id
group by title ,pub_id;
```

### *j)* Nome dos títulos vendidos pela loja ‘Bookbeat’; 

```
select title, stor_name from(( sales as s join titles as t on s.title_id = t.title_id) join stores as st on s.stor_id = st.stor_id )
where stor_name = 'Bookbeat'
```

### *k)* Nome de autores que tenham publicações de tipos diferentes; 

```
select au_fname,au_lname,count(t.type) from(( titleauthor as ta join titles as t on ta.title_id = t.title_id) join authors as a on ta.au_id = a.au_id )
group by au_lname, au_fname
having count(t.type) > 1 
order by au_fname asc 
```

### *l)* Para os títulos, obter o preço médio e o número total de vendas agrupado por tipo (type) e editora (pub_id);

```
SELECT type, pub_id, mediaPrice = avg(price), totalDeVendad = sum(qty) from sales as s inner join titles as t on t.title_id = s.title_id group by type, pub_id; 
```

### *m)* Obter o(s) tipo(s) de título(s) para o(s) qual(is) o máximo de dinheiro “à cabeça” (advance) é uma vez e meia superior à média do grupo (tipo);

```
select type, TypeMaxPrice = max(price), TypeAvgPrice= 1.5 * avg(price) from titles
group by type
having max(price) > 1.5 * avg(price)

```

### *n)* Obter, para cada título, nome dos autores e valor arrecadado por estes com a sua venda;

```
SELECT au_fname, title,qty from ((sales as s inner join titles as t on t.title_id = s.title_id) inner join titleauthor as ta on ta.title_id = t.title_id) 
inner join authors as au on au.au_id = ta.au_id;
```

### *o)* Obter uma lista que incluía o número de vendas de um título (ytd_sales), o seu nome, a faturação total, o valor da faturação relativa aos autores e o valor da faturação relativa à editora;

```
select title,ytd_sales, Facturacao = price * ytd_sales, auths_revenue = (royalty*0.01)*(price * ytd_sales), publisher_revenue = price * ytd_sales - ((royalty*0.01)*(price * ytd_sales))  from titles
order by title
```

### *p)* Obter uma lista que incluía o número de vendas de um título (ytd_sales), o seu nome, o nome de cada autor, o valor da faturação de cada autor e o valor da faturação relativa à editora;

```
select title,ytd_sales,CONCAT(au_fname , ' ' , au_lname) as author,
auths_revenue = (royaltyper*0.01)*(royalty*0.01)*(price * ytd_sales),publisher_revenue = price * ytd_sales - ((royalty*0.01)*(price * ytd_sales))
from(( titleauthor as ta join titles as t on ta.title_id = t.title_id) join authors as a on ta.au_id = a.au_id )
order by title,author
```

### *q)* Lista de lojas que venderam pelo menos um exemplar de todos os livros;

```
select stor_name,NtitlePerStore = count(distinct title)
from(( sales as sa join titles as t on sa.title_id = t.title_id) join stores as s on sa.stor_id = s.stor_id )
group by stor_name,title
having count(distinct title) = (select count(title)from titles) 
```

### *r)* Lista de lojas que venderam mais livros do que a média de todas as lojas;

```
select stor_name from sales as sa join stores as st on sa.stor_id=st.stor_id
group by stor_name
having sum(qty) > (select avg(qty) from sales)
```

### *s)* Nome dos títulos que nunca foram vendidos na loja “Bookbeat”;

```
select title from titles
except
select title from ( sales as sa join titles as t on sa.title_id = t.title_id) join stores as s on sa.stor_id = s.stor_id 
where stor_name = 'Bookbeat';
```

### *t)* Para cada editora, a lista de todas as lojas que nunca venderam títulos dessa editora; 

```
select pub_name,stor_name from stores,publishers
except
select pub_name,stor_name  from (((publishers as p join titles as t on p.pub_id = t.pub_id) join sales as sa on t.title_id = sa.title_id) join stores as s on sa.stor_id = s.stor_id )
```

## Problema 6.2

### ​5.1

#### a) SQL DDL Script
 
[a) SQL DDL File](ex_6_2_1_ddl.sql "SQLFileQuestion")

#### b) Data Insertion Script

[b) SQL Data Insertion File](ex_6_2_1_data.sql "SQLFileQuestion")

#### c) Queries

##### *a)*

```
SELECT Pname, Pnumber, Fname, Minit, Lname,Ssn FROM (project as p inner join works_on as w
on w.Pno = p.Pnumber) inner join  Employee as E on w.Essn = E.Ssn
```

##### *b)* 

```
SELECT E.Fname,E.Minit,E.Lname FROM Employee as E inner join Employee as s on 
E.Super_ssn = s.Ssn where s.Fname = 'Carlos' and s.Minit = 'D' and s.Lname = 'Gomes'
```

##### *c)* 

```
... Write here your answer ...
```

##### *d)* 

```
... Write here your answer ...
```

##### *e)* 

```
... Write here your answer ...
```

##### *f)* 

```
... Write here your answer ...
```

##### *g)* 

```
... Write here your answer ...
```

##### *h)* 

```
... Write here your answer ...
```

##### *i)* 

```
... Write here your answer ...
```

### 5.2

#### a) SQL DDL Script
 
[a) SQL DDL File](ex_6_2_2_ddl.sql "SQLFileQuestion")

#### b) Data Insertion Script

[b) SQL Data Insertion File](ex_6_2_2_data.sql "SQLFileQuestion")

#### c) Queries

##### *a)*

```
select * from (fornecedor as f left outer join Encomenda as e on f.NIF = e.FK_Fornecedor1)
where FK_Fornecedor1 IS NULL

```

##### *b)* 

```
select Nome,CodigoP,Munidades = avg(i.Unidades)from (Produto as p join Item as i on p.Codigo = i.CodigoP)
group by CodigoP,Nome
```


##### *c)* 

```
... Write here your answer ...
```


##### *d)* 

```
... Write here your answer ...
```

### 5.3

#### a) SQL DDL Script
 
[a) SQL DDL File](ex_6_2_3_ddl.sql "SQLFileQuestion")

#### b) Data Insertion Script

[b) SQL Data Insertion File](ex_6_2_3_data.sql "SQLFileQuestion")

#### c) Queries

##### *a)*

```
SELECT p.numUtente, nome, dataNasc, endereco from Paciente as p left outer join Prescricao 
as pr on p.numUtente = pr.numUtente where pr.numUtente is null
```

##### *b)* 

```
SELECT especialidade,PrescPorEspeci = count(especialidade) from Medico as 
m inner join Prescricao as pr on m.numSNS = pr.numMedico group by m.especialidade
```


##### *c)* 

```
SELECT farmacia, PrescPorFarm = count(numPresc) FROM Prescricao as pr where 
pr.farmacia != 'null' group by farmacia
```


##### *d)* 

```
... Write here your answer ...
```

##### *e)* 

```
... Write here your answer ...
```

##### *f)* 

```
... Write here your answer ...
```
