DROP database Company
CREATE database Company
GO
USE Company

CREATE TABLE department(
	Dnumber	       char(9)			not null,	
	Dname		   VARCHAR(40)		not null,	
	Mgr_ssn		   char(9)			,
	Mgr_start_date date				,
	primary key(Dnumber));

CREATE TABLE Employee(
	Fname		VARCHAR(40)		not null,
	Minit		VARCHAR(40)		not null,
	Lname		VARCHAR(40)		not null,
	Ssn			char(9)			not null,
	Bdate		date			not null,
	Address 	VARCHAR(60)		not null,
	Sex			char(2)			not null,
	Salary		char(9)			not null,
	Super_ssn	char(9)					,
	Dno			char(9)			not null,
	primary key(Ssn),
	foreign key(Dno) references department(Dnumber),
	foreign key(Super_ssn) references Employee(Ssn));

CREATE TABLE dependent(
	Essn			char(9)			not null,		
	Dependent_name	VARCHAR(60)		not null,
	Sex				char(2)		    not null,
	Bdate			date			not null,
	Relationship	VARCHAR(60)     not null,
	unique(Dependent_name),
	primary key(Essn),
	foreign key(Essn) references Employee(Ssn));

CREATE TABLE dept_location(
	Dnumber			char(9)			not null,	
	Dlocation	    VARCHAR(60)		not null,	
	unique(Dlocation),
	primary key(Dnumber),
	foreign key(Dnumber) references department(Dnumber));

CREATE TABLE project(
	Pname		VARCHAR(60)		not null,
	Pnumber		char(9)			not null,
	Plocation   VARCHAR(60)		not null,
	Dnum		char(9)			not null,	
	primary key(Pnumber),
	foreign key(Dnum) references department(Dnumber));

CREATE TABLE works_on(
	Essn	char(9)		not null,	
	Pno		char(9)		not null,		
	Hours	char(2)		not null,
	primary key(Essn,Pno),
	foreign key(Essn) references Employee(Ssn),
	foreign key(Pno) references project(Pnumber));
