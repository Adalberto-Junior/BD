DROP database stocks
CREATE database stocks
GO
USE stocks
CREATE TABLE Produto(
	Codigo		char(9)			not null,
	Nome		VARCHAR(40)		not null,	
	Preco		VARCHAR(40)		not null,
	IVA			varchar(9)		not null,
	Unidades	integer			not null,
	unique(Nome),
	unique(Unidades),
	primary key(Codigo));

CREATE TABLE Tipo_de_Fornecedor(	
	Codigo		char(9)			not null,
	Designacao	VARCHAR(60)		not null,
	unique(Designacao),
	primary key(Codigo));

CREATE TABLE Fornecedor(
	NIF			char(9)			not null,
	Nome		VARCHAR(40)		not null,
	Numero_fax	varchar(9)			not null,
	Endereco	VARCHAR(60)		,	
	Condicoes_pagamento	VARCHAR(60)	not null,
	tipo		char(9)			not null,
	primary key(NIF),
	foreign key(tipo) references Tipo_de_Fornecedor(codigo));

CREATE TABLE Encomenda(
	Numero_encomenda	integer	not null,
	Data_realizada		date	not null,	
	FK_Fornecedor1		char(9)	not null,
	primary key(Numero_encomenda),
	foreign key(FK_Fornecedor1) references Fornecedor(NIF));

CREATE TABLE Item(
	numEnc				integer	not null,
	CodigoP				char(9)	not null,
	Unidades			integer	not null,
	primary key(numEnc,Codigop),
	foreign key(numEnc) references Encomenda(Numero_encomenda),
	foreign key(CodigoP) references Produto(Codigo));

