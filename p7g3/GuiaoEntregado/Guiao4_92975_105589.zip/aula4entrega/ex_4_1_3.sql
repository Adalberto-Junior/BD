DROP database stocks
CREATE database stocks
GO
USE stocks
CREATE TABLE Produto(
	Nome		VARCHAR(40)		not null,	
	Preco		money			not null,
	IVA			varchar(9)		not null,
	Unidades	integer			not null,
	Codigo		char(9)			not null,
	unique(Nome),
	unique(Unidades),
	primary key(Codigo));

CREATE TABLE Tipo_de_Fornecedor(
	Designacao	VARCHAR(60)		not null,	
	Codigo		char(9)			not null,
	unique(Designacao),
	primary key(Codigo));

CREATE TABLE Fornecedor(
	Endereco	VARCHAR(60)		not null,	
	Numero_fax	char(9)			not null,
	Condicoes_pagamento	char	not null,
	Nome		VARCHAR(40)		not null,
	NIF			char(9)			not null,
	Codigo		char(9)			not null,
	primary key(Codigo,NIF),
	foreign key(Codigo) references Tipo_de_Fornecedor(codigo));

CREATE TABLE Encomenda(
	Data_realizada		date	not null,	
	Numero_encomenda	char(9)	not null,
	FK_Fornecedor1		char(9)	not null,
	FK_Fornecedor2		char(9)	not null,
	primary key(Numero_encomenda),
	foreign key(FK_Fornecedor1,FK_Fornecedor2) references Fornecedor(Codigo,NIF));

CREATE TABLE Item(
	Numero_encomenda	char(9)	not null,
	Codigo				char(9)	not null,
	primary key(Numero_encomenda,Codigo),
	foreign key(Numero_encomenda) references Encomenda(Numero_encomenda),
	foreign key(Codigo) references Produto(Codigo));