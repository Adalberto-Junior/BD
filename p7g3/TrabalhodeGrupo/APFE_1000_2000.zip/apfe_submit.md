# BD: Trabalho Prático APFE

**Grupo**: PXGY
- António Fictício, MEC: 1000
- João Inventado, MEC: 2000

## Introdução / Introduction
 
Escreva uma pequena introdução sobre o trabalho.
Write a simple introduction about your project.

## ​Análise de Requisitos / Requirements


## DER


![DER Diagram!](der.jpg "AnImage")

## ER

![ER Diagram!](er.jpg "AnImage")