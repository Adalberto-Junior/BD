﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoBDrestauracao
{
    internal class MesaDAO
    {
        public List<Mesa> mesas = new List<Mesa>();
    }
}
