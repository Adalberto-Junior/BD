/*
Tringers:
-Atualizar o estado da mesa!
-Atualizar a quantidade do produto
-Ao fornecer um pedido verificar se o produto em conta est� disponivel. 

UDF:
-Fun��o para imprimir a descri��o da conta;
-
Indices:
--Nome do produto
--Numero da mesa

SP:
-Fechar a conta
-O produto 


*/

/*
CREATE FUNCTION dbo.DescricaoConta() RETURNS @Descricao TABLE (Codigo int, produto varchar(60), valorT money)
AS
BEGIN
INSERT @Descricao (Codigo, produto, valorT)
SELECT Codigo, produto, valorT 
FROM Conta as c JOIN Pedido as p ON p.Numero = c.Numero inner join Seleciona as s on s.NumPedido = p.Numero inner join Produto as Pr on Pr.Nome = s.NomeP;
INSERT @Price (Code, EffectiveDate, Price) 
SELECT Code, Null, Avg(Price)
FROM Product JOIN Price ON Price.ProductID = Product.ProductID
GROUP BY Codigo; 
RETURN;
END;
GO
SELECT * FROM dbo.ftPriceAvg();

*/


CREATE Trigger NewClient on dbo.Mesa 
	After UPDATE
as
Begin
	
	if(Select count(*) from inserted) > 0
		begin
		Declare @estado as varchar(30);
		Select @estado = Estado from  inserted;
		if (@estado = 'Ocupado')
		begin
			RAISERROR ('A Mesa j� se encontra ocupada!',16,1);
		end;
		else
			 if (@estado = 'Reservado')
				begin
					RAISERROR ('A mesa Encontra-se Reservada!',16,1);
				end;
			else
				begin
					update  Mesa set Mesa.Estado = (select Estado from inserted), Mesa.NumCliente = (select Mesa.NumCliente from inserted)  where Mesa.Numero = (select Numero from inserted);
					Print 'Update Action was sucess!';
				end;
	end;
end;
		
go
update Mesa set Estado = 'Ocupado', NumCliente = 10 where Numero = 4;
update Mesa set Estado = 'Reservado', NumCliente = 10 where Numero = 6;
update Mesa set Estado = 'Ocupado', NumCliente = 4 where Numero = 7;


Select * from Mesa



/*
CREATE Trigger NewClient on dbo.Mesa 
	After insert, UPDATE
as
Begin
	
	if(Select count(*) from inserted) > 0
		begin
		Declare @estado as varchar(30);
		Declare @NumClient as int;
		Declare @number as int;
		Select @number = Numero from  inserted;
		Select @estado = Estado from Mesa where Numero = @number; 
		if @estado = 'Ocupado'
			RAISERROR ('A Mesa j� se encontra ocupada!',16,1);
		else if @estado = 'Reservado'
			RAISERROR ('A mesa Encontra-se Reservada!',16,1);
		else
		begin
			update M
			
			set Estado = (select Estado from inserted), NumCliente = (select NumCliente from inserted) from Mesa as M 
		 inner join inserted as I on I.Numero = M.Numero 
		 left join deleted as D on D.Numero = M.Numero;
		 --where Mesa.Numero = (select Numero from inserted);
			Print 'Update Action was sucess!';
		end
	end
end
*/