DROP database Pres_Elet_Medicamentos
CREATE database Pres_Elet_Medicamentos
GO

USE Pres_Elet_Medicamentos

CREATE TABLE Medico(
	Nome			 VARCHAR(40)		not null,	
	Especialidade  	 VARCHAR(20)		not null,
	N_de_id_SNS		 char(9)			not null,

	primary key(N_de_id_SNS)
	);

CREATE TABLE Paciente(
	Nome 				VARCHAR(40)			not null,	
	Data_de_nascimento	date				not null,	
	Endereco			VARCHAR(40)			not null,
	Numero_de_utente	char(9)				not null, 
	primary key(Numero_de_utente)
	);

CREATE TABLE Farmacia(
	Nome 				VARCHAR(40)			not null,	
	Telefone			char(9)				not null,
	Endereco			VARCHAR(40)			not null,
	NIF					char(9)				not null,
	unique(Telefone),
	primary key(NIF),
	
	);

CREATE TABLE Prescricao(
	Data_Prescricao		Date			not null,
	Numero_unico  		integer			not null,	
	FK_Paciente			char(9)			not null,	
	FK_Medico			char(9)			not null,
	FK_Farmacia			char(9)			not null,
	primary key(Numero_unico),
	foreign key(FK_Paciente) references Paciente(Numero_de_utente),
	foreign key(FK_Medico)	 references Medico(N_de_id_SNS),
	foreign key(FK_Farmacia) references Farmacia(NIF)
	);

CREATE TABLE Farmaceutica(
	Nome 			VARCHAR(40)			not null,	
	Telefone		char(9)				not null,	
	Endereco		VARCHAR(40)			not null,
	No_de_reg_nacio char(9)				not null,

	unique(Telefone),
	primary key(No_de_reg_nacio),
	);

CREATE TABLE Farmaco(
	Nome_comercial 		VARCHAR(40)			not null,
	Nome_unico			VARCHAR(40)			not null,
	Formula				VARCHAR(40)			not null,
	No_de_reg_nacio		char(9)				not null,
	unique(Formula),
	primary key(Nome_unico),
	foreign key(No_de_reg_nacio) references Farmaceutica(No_de_reg_nacio),
	);

CREATE TABLE Adquirir(
	Formula				VARCHAR(40)		not null,
	Numero_unico  		integer			not null,	
					
	primary key(Formula,Numero_unico),
	foreign key(Numero_unico) references Prescricao(Numero_unico),
	foreign key(Formula	) references Farmaco(Formula	),
	);